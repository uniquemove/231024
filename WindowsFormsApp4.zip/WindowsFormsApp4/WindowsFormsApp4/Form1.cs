﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp4
{
    public partial class Form1 : Form
    {
        List<Product> products = new List<Product>();
        public Form1()
        {
            InitializeComponent();
        }

        public class Product
        {
            public string MaSP { get; set; }
            public string TenSP { get; set; }
            public decimal DonGia { get; set; }
            public string HinhAnh { get; set; }
            public string MoTaNgan { get; set; }
            public string MoTaChiTiet { get; set; }
            public string LoaiSP { get; set; }
        }



        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void panel2_Paint(object sender, PaintEventArgs e)
        {

        }

        private void button3_Click(object sender, EventArgs e)
        {
            try
            {
                // Tạo đối tượng Product mới từ thông tin trong TextBox
                Product product = new Product()
                {
                    MaSP = textBox1.Text,  // Mã sản phẩm
                    TenSP = textBox2.Text,  // Tên sản phẩm
                    DonGia = decimal.Parse(textBox3.Text), // Đơn giá (chuyển sang kiểu số)
                    HinhAnh = textBox4.Text,  // Hình ảnh
                    MoTaNgan = textBox5.Text,  // Mô tả ngắn
                    MoTaChiTiet = textBox6.Text,  // Mô tả chi tiết
                    LoaiSP = textBox7.Text   // Loại sản phẩm
                };

                // Thêm sản phẩm vào danh sách
                products.Add(product);

                // Cập nhật lại DataGridView với danh sách sản phẩm mới
                dataGridView1.DataSource = null;  // Xóa dữ liệu hiện tại
                dataGridView1.DataSource = products;  // Cập nhật lại với danh sách sản phẩm

                MessageBox.Show("Thêm sản phẩm thành công!");
            }
            catch (Exception ex)
            {
                MessageBox.Show("Lỗi khi thêm sản phẩm: " + ex.Message);
            }
        }

        // Xử lý khi nhấn nút "Làm mới"
        private void button2_Click(object sender, EventArgs e)
        {
            // Xóa trắng các ô nhập liệu
            textBox1.Text = "";
            textBox2.Text = "";
            textBox3.Text = "";
            textBox4.Text = "";
            textBox5.Text = "";
            textBox6.Text = "";
            textBox7.Text = "";
        }
    }
        }


    
